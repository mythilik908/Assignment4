package com.cg.match;

import com.cg.team.Team;

public class Match {

	private String date;
	private Team teamOne;
	private Team teamTwo;
	private String venue;
	private Team team;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Team getTeamOne() {
		return teamOne;
	}
	public void setTeamOne(Team teamOne) {
		this.teamOne = teamOne;
	}
	public Team getTeamTwo() {
		return teamTwo;
	}
	public void setTeamTwo(Team teamTwo) {
		this.teamTwo = teamTwo;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public Team getTeam() {
		return team;
	}
	public void setTeam(Team team) {
		this.team = team;
	}
	@Override
	public String toString() {
		return String.format("%-15s %-15s %-15s %s",date,teamOne.getName(),teamTwo.getName(),venue,team);
	}
		
}
