package com.cg.match;

import com.cg.team.Team;

public class MatchBO {
	public Match createMatch(String data, Team[] teamList)
	{
		Match matches = new Match();
		String[] matchDetails = data.split(",");
		matches.setDate(matchDetails[0]);
		matches.setVenue(matchDetails[3]);
		
	for(int i=1;i<=2;i++)
	{
		if(teamList[i].getName().contains(matchDetails[1]))
		{
			matches.setTeamOne(teamList[i]);
		}
		else if(teamList[i].getName().contains(matchDetails[2]))
		{
			matches.setTeamTwo(teamList[i]);
		}
	} 
		return matches;
	}		
	
	public Team[] findTeam(String matchDate, Match[] matchList) 
	{
		Team[] subTeam = new Team[2];
		for(int i =1; i<=matchList.length; i++)
		{
			if(matchList[i].getDate().contains(matchDate)){
				subTeam[0] = matchList[i].getTeamOne();
				subTeam[1] = matchList[i].getTeamTwo();
				return subTeam;
			}
		}
		return subTeam;
	}
	
	public void findAllMatchesOfTeam(String teamName, Match[] matchList) throws NullPointerException
		{
			for(int i =1; i<= matchList.length;i ++)
			{
				if(matchList[i].getTeamOne().getName().equals(teamName) || matchList[i].getTeamTwo().getName().equals(teamName))
				{
					System.out.println(matchList[i].toString());
				}
			}
			
		}
		
	}
