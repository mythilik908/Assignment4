package com.cg.main;

import java.util.Scanner;

import com.cg.match.Match;
import com.cg.match.MatchBO;
import com.cg.player.Player;
import com.cg.player.PlayerBO;
import com.cg.team.Team;
import com.cg.team.TeamBO;

public class TestMain {
public static void main(String[] args) {
	PlayerBO playerBO =new PlayerBO();
	TeamBO teamBO = new TeamBO();
	MatchBO matchBO = new MatchBO();
	
	Scanner scan = new Scanner(System.in);
	
	Player[] players = new Player[10];
	Match[] matches= new Match[10];
    Team[] teams = new Team[10];
    Team[] team = new Team[10];
	
   System.out.println("Enter the Player Count");
   int playerCount = scan.nextInt();
   
   for(int i=1;i<=playerCount;i++)
   {
   playerBO = new PlayerBO();
   System.out.println("Enter Player "+ i + " Details");
   String input= scan.next();
   players[i]= playerBO.createPlayer(input);
   }
   
  System.out.println("Enter the Team Count");
  int teamCount = scan.nextInt();
  
  for(int i=1;i <= teamCount ;i++) {
  teamBO = new TeamBO();
  System.out.println("Enter Team "+ i + " Details");
  String input = scan.next();
  teams[i]= teamBO.createTeam(input, players);  
   }
  
  System.out.println("Enter the Match Count");
  int matchCount = scan.nextInt();
 
  for(int i=1; i <= matchCount; i++)
  {
	  matchBO = new MatchBO();
	  System.out.println("Enter Match "+ i + " Details");
	  String input = scan.next();
	  matches[i] = matchBO.createMatch(input, teams);
  }
  while(true) {
	  
	  System.out.println("Menu: ");
	  System.out.println("1) Find Team");
	  System.out.println("2) Find All Matches in a Specific Venue");
	  System.out.println("Type 1 or 2");
	  System.out.println("Enter your choice");
	  int choice = scan.nextInt();
	  if(choice == 1)
	      {
		  System.out.println("Enter Match Date");
		  String date = scan.next();
		  team = matchBO.findTeam(date,matches);
		  System.out.println("Team");
		  System.out.println(team[0].getName()+ ", "+ team[1].getName());
		  }
	  else if (choice == 2)
	  {
		  System.out.println("Match Details");
		  System.out.println("Enter Team Name");
		  String name = scan.next();
		  matchBO.findAllMatchesOfTeam(name, matches);
	  }
	  else
	  {
		  System.out.println("Please enter 1 or 2 options only");
		  System.exit(0);
	  }
}	   

}
}