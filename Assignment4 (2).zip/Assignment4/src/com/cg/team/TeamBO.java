package com.cg.team;

import com.cg.player.Player;

public class TeamBO {
	
	public Team createTeam(String data, Player[] PlayerList)
	{
	Team teams = new Team();

	
	String[] teamDetails = data.split(",");
	
	for(int i=1;i<= teamDetails.length;i++)
	{
	    teams = new Team();
		teams.setName(teamDetails[0]);
	}
	for(int j=1;j<= teamDetails.length;j++) 
	{
		if(PlayerList[j].getName().contains(teamDetails[1]))	
		{
		teams.setPlayer(PlayerList[j]);
		}
	}
	return teams;		
	}
}
