package com.cg.team;

import com.cg.player.Player;

public class Team {

	private String name;
	Player player;
	
	public Team() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Player getPlayer() {
		return player;
	}
	public void setPlayer(Player player) {
		this.player = player;
	}
	@Override
	public String toString() {
		return "Team [name=" + name + ", player=" + player + "]";
	}
	
	
}
