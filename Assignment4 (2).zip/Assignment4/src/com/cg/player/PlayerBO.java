package com.cg.player;

public class PlayerBO {
	public Player createPlayer(String data)
	{	
	Player players = new Player();
	String[] playerDetails = data.split(",");
		players = new Player();
		players.setName(playerDetails[0]);
		players.setCountry(playerDetails[1]);
		players.setSkill(playerDetails[2]);
	return players;
}
}
